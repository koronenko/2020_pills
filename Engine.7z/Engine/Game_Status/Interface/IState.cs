﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Engine.Game_Status.Interface
{
    public interface IGame_Status
    {
        bool IStatusGame_Over();
        bool IStatus_Pause();
    }
}
