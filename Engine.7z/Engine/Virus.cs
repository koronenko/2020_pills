﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Engine
{
    class Virus
    {
        public Position Position
        {
            get;
        }
        public Color Color
        {
            get;
        }

        public Virus(Position position, Color color)
        {
            Position = position;
            Color = color;
        }
    }
}
