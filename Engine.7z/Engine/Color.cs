﻿using System;

namespace Engine
{
    public enum Color //перерахування з 16-системи кольорів
    {
       blue = 1,
       green = 2,
       violet = 3

    }
}
