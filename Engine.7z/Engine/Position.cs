﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Engine
{
    class Position
    {
        public int Column
        {
            get;
            set;
        }
        public int Row 
        {
            get;
            set;
        }

        public Position() { }

        public Position(int column, int row)
        {
            Row = row;
            Column = column;
        }

        public Position(Position position)
        {
            Row = position.Row;
            Column = position.Column;
        }


    }
}
