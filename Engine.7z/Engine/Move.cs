﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Engine
{
    public enum Move 
    { 
        None,
        Down,
        Left,
        Right,
        RotateRight,
        RotateLeft,
        Fall
    }
}
