﻿namespace WF_Menu_Start_Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.BLUE_VIRUS = new System.Windows.Forms.PictureBox();
            this.VIOLET_VIRUS = new System.Windows.Forms.PictureBox();
            this.GREEN_VIRUS = new System.Windows.Forms.PictureBox();
            this.COUNTER_VIRUS = new System.Windows.Forms.Label();
            this.COUNTER_LEVEL = new System.Windows.Forms.Label();
            this.SCORE = new System.Windows.Forms.Label();
            this.gameDisplay = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BLUE_VIRUS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VIOLET_VIRUS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GREEN_VIRUS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameDisplay)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 250;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(799, 438);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // BLUE_VIRUS
            // 
            this.BLUE_VIRUS.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BLUE_VIRUS.Image = ((System.Drawing.Image)(resources.GetObject("BLUE_VIRUS.Image")));
            this.BLUE_VIRUS.InitialImage = null;
            this.BLUE_VIRUS.Location = new System.Drawing.Point(67, 230);
            this.BLUE_VIRUS.Name = "BLUE_VIRUS";
            this.BLUE_VIRUS.Size = new System.Drawing.Size(70, 70);
            this.BLUE_VIRUS.TabIndex = 2;
            this.BLUE_VIRUS.TabStop = false;
            // 
            // VIOLET_VIRUS
            // 
            this.VIOLET_VIRUS.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.VIOLET_VIRUS.Image = ((System.Drawing.Image)(resources.GetObject("VIOLET_VIRUS.Image")));
            this.VIOLET_VIRUS.InitialImage = null;
            this.VIOLET_VIRUS.Location = new System.Drawing.Point(71, 310);
            this.VIOLET_VIRUS.Name = "VIOLET_VIRUS";
            this.VIOLET_VIRUS.Size = new System.Drawing.Size(70, 70);
            this.VIOLET_VIRUS.TabIndex = 3;
            this.VIOLET_VIRUS.TabStop = false;
            // 
            // GREEN_VIRUS
            // 
            this.GREEN_VIRUS.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.GREEN_VIRUS.Image = ((System.Drawing.Image)(resources.GetObject("GREEN_VIRUS.Image")));
            this.GREEN_VIRUS.InitialImage = null;
            this.GREEN_VIRUS.Location = new System.Drawing.Point(145, 273);
            this.GREEN_VIRUS.Name = "GREEN_VIRUS";
            this.GREEN_VIRUS.Size = new System.Drawing.Size(70, 70);
            this.GREEN_VIRUS.TabIndex = 4;
            this.GREEN_VIRUS.TabStop = false;
            // 
            // COUNTER_VIRUS
            // 
            this.COUNTER_VIRUS.AutoSize = true;
            this.COUNTER_VIRUS.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.COUNTER_VIRUS.Font = new System.Drawing.Font("OCR A Extended", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COUNTER_VIRUS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.COUNTER_VIRUS.Location = new System.Drawing.Point(604, 373);
            this.COUNTER_VIRUS.Name = "COUNTER_VIRUS";
            this.COUNTER_VIRUS.Size = new System.Drawing.Size(136, 23);
            this.COUNTER_VIRUS.TabIndex = 6;
            this.COUNTER_VIRUS.Text = "000000000";
            // 
            // COUNTER_LEVEL
            // 
            this.COUNTER_LEVEL.AutoSize = true;
            this.COUNTER_LEVEL.BackColor = System.Drawing.SystemColors.WindowText;
            this.COUNTER_LEVEL.Font = new System.Drawing.Font("OCR A Extended", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COUNTER_LEVEL.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.COUNTER_LEVEL.Location = new System.Drawing.Point(604, 296);
            this.COUNTER_LEVEL.Name = "COUNTER_LEVEL";
            this.COUNTER_LEVEL.Size = new System.Drawing.Size(136, 23);
            this.COUNTER_LEVEL.TabIndex = 7;
            this.COUNTER_LEVEL.Text = "000000000";
            // 
            // SCORE
            // 
            this.SCORE.AutoSize = true;
            this.SCORE.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SCORE.Font = new System.Drawing.Font("OCR A Extended", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCORE.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SCORE.Location = new System.Drawing.Point(90, 55);
            this.SCORE.Name = "SCORE";
            this.SCORE.Size = new System.Drawing.Size(136, 24);
            this.SCORE.TabIndex = 8;
            this.SCORE.Text = "000000000";
            // 
            // gameDisplay
            // 
            this.gameDisplay.BackColor = System.Drawing.Color.LightCyan;
            this.gameDisplay.Location = new System.Drawing.Point(288, 166);
            this.gameDisplay.Name = "gameDisplay";
            this.gameDisplay.Size = new System.Drawing.Size(200, 225);
            this.gameDisplay.TabIndex = 0;
            this.gameDisplay.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.gameDisplay);
            this.groupBox1.Controls.Add(this.SCORE);
            this.groupBox1.Controls.Add(this.COUNTER_LEVEL);
            this.groupBox1.Controls.Add(this.COUNTER_VIRUS);
            this.groupBox1.Controls.Add(this.GREEN_VIRUS);
            this.groupBox1.Controls.Add(this.VIOLET_VIRUS);
            this.groupBox1.Controls.Add(this.BLUE_VIRUS);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.MenuText;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(799, 450);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "2020 pills";
            this.TransparencyKey = System.Drawing.Color.DimGray;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BLUE_VIRUS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VIOLET_VIRUS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GREEN_VIRUS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameDisplay)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox BLUE_VIRUS;
        private System.Windows.Forms.PictureBox VIOLET_VIRUS;
        private System.Windows.Forms.PictureBox GREEN_VIRUS;
        private System.Windows.Forms.Label COUNTER_VIRUS;
        private System.Windows.Forms.Label COUNTER_LEVEL;
        private System.Windows.Forms.Label SCORE;
        private System.Windows.Forms.PictureBox gameDisplay;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

