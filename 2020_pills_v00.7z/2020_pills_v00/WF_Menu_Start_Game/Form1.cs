﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_Menu_Start_Game
{
    //взято 
    //https://docs.microsoft.com/ru-ru/dotnet/desktop/winforms/advanced/how-to-create-graphics-objects-for-drawing?view=netframeworkdesktop-4.8

    public partial class Form1 : Form
    {
        //Додаємо на форму PictureBox та створюємо Timer.
        // Задаємо в константи розмір поля та розмір клитини в пікселях
        private const int CELL_SIZE = 25;

        private GamePad gamePad;
        public Form1()
        {
            InitializeComponent();
            gamePad = new GamePad(gameDisplay.Width / CELL_SIZE, gameDisplay.Height / CELL_SIZE);
            gamePad.GeneraateViruses();
        }


        public void ShowGamePad()
        {
            // Заповнення поля по краях та колодязь в PictureBox
            var gr = Graphics.FromImage(bitfield);

            //Очистити поле
            gr.Clear(Color.Azure);
              gr.DrawRectangle(Pens.DarkTurquoise, k, k, (width - 1) * k, (height - 1) * k);
            for (int i = 0; i < width; i++)
                for (int j = 0; j < height; j++)
            gameDisplay.Image = bitfield;
        }
    }

    public class Cell
    {
        public const int WHITE_COLOR = 0;
        public const int PURPLE_COLOR = 1;
        public const int GREEN_COLOR = 2;
        public const int BLUE_COLOR = 3;

        public const int EMPTY_TYPE = 0;
        public const int SINGLE_PILLS_TYPE = 1;
        public const int TOP_PILLS_TYPE = 2;
        public const int BOTTOM_PILLS_TYPE = 3;
        public const int LEFT_PILLS_TYPE = 4;
        public const int RIGHT_PILLS_TYPE = 5;
        public const int VIRUS_TYPE = 6;

        public int Type { get; set; }
        public int Color { get; set; }

        public Cell(int type, int color)
        {
            Type = type;
            Color = color;
        }

        public Cell() : this(EMPTY_TYPE, WHITE_COLOR)
        {
        }
    }

    public class GamePad
    {
        private const int MINIMAL_SIZE = 2;
        private const int VIRUSES_SHIFT = 2;

        public int PadWidth { get; set; }
        public int PadHeight { get; set; }

        private Cell[,] gameCells;

        public GamePad(int width, int height)
        {
            if (width > MINIMAL_SIZE && height > MINIMAL_SIZE) {
                PadWidth = width;
                PadHeight = height;
            }
            else
            {
                PadWidth = 0;
                PadHeight = 0;
            }

            ClearPad();
        }

        public void ClearPad()
        {
            gameCells = new Cell[PadWidth, PadHeight];
            for (int i = 0; i < PadWidth; i++)
            {
                for (int j = 0; j < PadHeight; j++)
                {
                    gameCells[i, j] = new Cell();
                }
            }
        }

        public void GeneraateViruses()
        {
            if (PadWidth > MINIMAL_SIZE && PadHeight > MINIMAL_SIZE) {
                Random generator = new Random();

                int purpleWidth = generator.Next(0, PadWidth - 1);
                int purpleHeight = generator.Next(0, PadHeight - VIRUSES_SHIFT - 1);
                SetCellData(purpleWidth, purpleHeight, Cell.VIRUS_TYPE, Cell.PURPLE_COLOR);

                int blueWidth = generator.Next(0, PadWidth - 1);
                int blueHeight = generator.Next(0, PadHeight - VIRUSES_SHIFT - 1);
                while (purpleWidth == blueWidth && purpleHeight == blueHeight)
                {
                    blueWidth = generator.Next(0, PadWidth - 1);
                    blueHeight = generator.Next(0, PadHeight - VIRUSES_SHIFT - 1);
                }
                SetCellData(blueWidth, blueHeight, Cell.VIRUS_TYPE, Cell.BLUE_COLOR);

                int greenWidth = generator.Next(0, PadWidth - 1);
                int greenHeight = generator.Next(0, PadHeight - VIRUSES_SHIFT - 1);
                while (purpleWidth == greenWidth && purpleHeight == greenHeight && blueWidth == greenWidth && blueHeight == greenHeight)
                {
                    greenWidth = generator.Next(0, PadWidth - 1);
                    greenHeight = generator.Next(0, PadHeight - VIRUSES_SHIFT - 1);
                }

                SetCellData(greenWidth, greenHeight, Cell.VIRUS_TYPE, Cell.GREEN_COLOR);
            }
        }

        public void SetCellData(int width, int height, int type, int color)
        {
            SetCellType(width, height, type);
            SetCellColor(width, height, color);
        }

        public void SetCellType(int width, int height, int type)
        {
            gameCells[width, height].Type = type;
        }

        public void SetCellColor(int width, int height, int color)
        {
            gameCells[width, height].Color = color;
        }
    }
}
