﻿using System;
/// <summary>
// 99ccff - блакитний
// 993399 - фіолетовий
// 33cc99 - зелений
/// </summary>
namespace Engine
{
    public enum Color //перерахування кольорів
    {
        blue = 1,
        green = 2,
        violet = 3,
        white = 4,
        black = 5,
        grey = 6,
        purple = 7,
        none = 8,
        dark_grey = 9
    }
}
