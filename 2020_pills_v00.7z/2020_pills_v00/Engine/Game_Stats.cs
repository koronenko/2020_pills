﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// звязок рушія та інтерфейсу для передачі статусу гри (завершення, пауза, гра)
/// </summary>
namespace Engine
{
    class Game_Stats
    {
    }
}
