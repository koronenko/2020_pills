﻿using System;
using System.Collections.Generic;
using System.Text;

/// <summary>
/// колодязь-матриця, як поле для гри, для розуміння представлення
///  ----------
///  | x1, x2 |
///  | y1, y2 |
///  ----------
/// </summary>
namespace Engine
{
    public class Matrix // сама матриця, задаємо ікси Х, переробила на авто
    {
        public byte X1 {get; private set;}
        public byte X2 {get; private set;}
        public byte Y1 {get; private set;} // задаємо Y
        public byte Y2 {
            get
            {
                return 0;
            }
        }

        // -------------------------------

        public Matrix(byte x1, byte x2) //X1 --> x1; X2 --> x2; Y1 == 0
        {
            this.X1 = x1;
            this.X2 = x2;
            this.Y1 = 0;
        }

        public Matrix(Matrix matrix)
        {
            X1 = matrix.X1;
            X2 = matrix.X2;
            Y1 = matrix.Y1;
        }

        // перерахунок

        public override string ToString() // тут твориться стрінгова магія =)
        {
            return $"{X1},{X2},{Y1},{Y2}";
            //return string.Format
            //("[Matrix: x1={0}, x2={1}, 
            //y1={2}, y2={3}]", x1, x2, y1, y2);
        }

        // Повороти пігулки

        public void Rotate_Left()
        {
            if (Y1 == 0)
            {
                Y1 = X1;
                X1 = X2;
                X2 = 0;
            }
            else
            {
                X2 = Y1;
                Y1 = 0;
            }
        }

    }
}
