﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
/// <summary>
/// клас рендом
/// </summary>
namespace Engine
{
    public class Random : System.Random
        {
        private static Random _instance;
        public static Random Instance()
        {
            return _instance ?? (_instance = new Random());
        }
        private Random(int seed) : base(seed) { } //так можна писати чи це поганий стиль? так зване базове насіння =)
        private Random() : base() { }

        public T Next_Color<T>() // задаємо кольори половинок
        {
            // задаємо щоб потім використати
            var types = Enum.GetValues(typeof(T)).Cast<T>().ToArray();
            return types[Next(0, types.Length)];
        }
        public T Next_Enum<T>()
        {
            // задаємо щоб потім використати
            var types = Enum.GetValues(typeof(T)).Cast<T>().ToArray();
            return types[Next(0, types.Length)];
        }
        public T Next_Enum<T>(IEnumerable<T> excludes)
        {
            // задаємо щоб потім використати
            var types = Enum.GetValues(typeof(T)).Cast<T>().Except(excludes).ToArray();
            return types[Next(0, types.Length)];
        }

        public T Next<T>(T[] array)
        {
            return array[Next(0, array.Length)];
        }

        public Position Next(byte[][] jaggedArray,int maxHeight) // помилка, ще думаю над нею
        {
            var availablePositions = new List<Position>();
            for (int i = 0; i < Math.Min(maxHeight, jaggedArray.Length); i++)
            {
                for (int j = 0; j < jaggedArray[0].Length; j++)
                {
                    if (jaggedArray[i][j] == 0)
                    {
                        availablePositions.Add(new Position(j, i));
                    }
                }
            }

            if (availablePositions.Count == 0)
            {
                return null;
            }

            return availablePositions[Next(0, availablePositions.Count)];
        
        }

        public void Set_New_Seed(int i)
        {
            _instance = new Random(i);
        }
    }
}
