﻿using Engine.Game_Status.Interface;
using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// завершення гри, просте повернення значення
/// </summary>
namespace Engine.Game_Status
{
    public class Game_Over : GOP_Status // дивитись Status.cs
    {
        public override bool IStatus_Game_Over()
        {
            return true;
        }
    }
}
