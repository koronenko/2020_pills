﻿using Engine.Game_Status.Interface;
using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// дивитись в інтерфейс #IStatus.cs
/// </summary>
namespace Engine.Game_Status
{
    public abstract class GOP_Status : IGame_Status //GOP- це  я так скоротила GAME OVER + PAUSE =)))
    {
        public virtual bool IStatus_Game_Over()
        {
            return false;
        }

        public bool IStatus_Pause()
        {
            return false;
        }

    }
}
