﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
///  відловлювання паузе, буде просте повернення значення
/// </summary>
namespace Engine.Game_Status
{
    public class Pause : GOP_Status // дивитись Status.cs
    {

    }
}
