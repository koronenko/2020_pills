﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
///  просте повернення значення, якщо гра продовжується
/// </summary>
namespace Engine.Game_Status
{
    public class Play : GOP_Status // дивитись Status.cs
    {

    }
}
