﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// Інтерфейс для передачі статусу гри
/// </summary>
namespace Engine.Game_Status.Interface
{
    public interface IGame_Status // дивитись Status.cs
    {
        bool IStatus_Game_Over(); // відловлюємо статус завершення гри 
        bool IStatus_Pause(); // відловлюємо статус пауза булеві змінні найпростіший вибір
    }
}
