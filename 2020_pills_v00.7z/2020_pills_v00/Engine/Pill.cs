﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.ComTypes;
using System.Resources;
/// <summary>
/// тут як у вірусах задаємо колір, розміщення, але нам треба відслідковувати кілька нових значень
/// положення в нашому колодязі-матриці
/// </summary>
namespace Engine
{
    public class Pill
    {
        public Matrix Matrix {get; private set;} // переробила на авто і додала private
        public bool Place {get; set;} // місцеположення
        public Position Position {get; private set;} //не розумію, чому тут свариться? розміщення-позиція
        public bool Uni_Color {get; private set;} // задання кольору
        public bool Rotate {get; private set;} // обертання пігулки

        // тернарний оператор для операції зміщення кольору при обертанні, тут можна похвалити за цікаву ідею використання))))
        public int Unique_Rotation => Uni_Color ? 2 : 4;
        //
        public new Pill(Position position) // помилка знову... отримали рендомний колір для нової пігулки, отримуємо значення позиції
        {
            Matrix = Get_Random_Pill();
            Place = false;
            Position = position;
        }

        public Pill(Color type1, Color type2, Position position) // помилка знову... два кольори отримали
        {
            Uni_Color = type1 == type2;
            Matrix = new Matrix((byte)type1, (byte)type2);
            Place = false;
            Position = position;
        }

        public Pill Clone() // Відтворюємо пігулку, маємо позицію та обертання.
        { 
            return new Pill(new Position(this.Position))
            {
                Place = this.Place,
                Rotate = this.Rotate,
                Matrix = new Matrix(this.Matrix)
            };
        }

        public void Move(Move move) //рухаємо пігулку
        {
            switch (move)
            {
                case Engine.Move.Down: // Down з рушія(Engine) наше перерахування Move.cs
                    this.Position.Row--; //зміщуємо по Row
                    break;
                case Engine.Move.Left: //Left з рушія(Engine) наше перерахування Move.cs
                    this.Position.Column--; // зміщуємо по Column
                    break;
                case Engine.Move.Right: // Right з рушія(Engine) наше перерахування Move.cs
                    this.Position.Row++; // зміщуємо по Row (! перевірити теорію !)
                    break;
                case Engine.Move.Rotate_Left: // Обертання вліво (! дописати !)
                    this.Matrix.Rotate_Left();
                    this.Rotate = !this.Rotate;
                    break;

                default:
                    {
                        throw new InvalidOperationException("Move not valid"); // передаємо помилку
                    }
            }
        }
        internal static Matrix Get_Random_Pill() // дивитись Get_Value(typeof(Color)) в Random.cs
        {
           var Block_Type = Enum.GetValues(typeof(Color)).Cast<Color>().ToArray();

            return new Matrix((byte) Random.Instance().Next_Enum<Color>(), (byte) Random.Instance().Next_Enum<Color>
());
                }
        // злиття
        internal void Merge(Pill tempPill) // мерджимо tempPill
        {
            this.Matrix = new Matrix(tempPill.Matrix);
            this.Place = tempPill.Place;
            this.Position = new Position(tempPill.Position);
            this.Rotate = tempPill.Rotate;
            this.Uni_Color = tempPill.Uni_Color;
        }
    }
}
