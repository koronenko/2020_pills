﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// тут задамо нашим вірусам колір та позицію, трохи простіше ніж пігулки, бо не треба обертати.
/// </summary>
namespace Engine
{
    class Virus
    {
        public Position Position {get;} // переробила на авто
        public Color Color {get;}

        public Virus(Position position, Color color) // просте задавання розміщення та кольору, все інше через рендом
        {
            Position = position;
            Color = color;
        }
    }
}
