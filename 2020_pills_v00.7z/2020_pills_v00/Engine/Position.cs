﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
/// <summary>
/// будемо передавати в пігулки позицію
/// </summary>
namespace Engine
{
    class Position
    {
        // представляємо поле гри, як просто колодязь з рядками та стовпчиками, щоб відловлювати позицію
        public int Column {get; set;} //переробила на авто, бо було так як я запитувала зі скобками
        public int Row {get; set;}
        public Position() { }
        public Position(int column, int row)
        {
            Row = row;
            Column = column;
        }
        public Position(Position position)
        {
            Row = position.Row;
            Column = position.Column;
        }

        //перезапис значень
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return(int) (Column + Row * 1E6); //це значення override (1E6) я гуглила
        }

        public static bool operator == (Position obj1, Position obj2)
        {
            // дізнаємося значення
            if (ReferenceEquals(obj1, obj2))
            {
                return true;
            }

            if (ReferenceEquals(obj1, null))
            {
                return false;
            }

            if (ReferenceEquals(obj2, null))
            {
                return false;
            }

            return obj1.Column == obj2.Column && obj1.Row == obj2.Row;
        }

        public static bool operator !=(Position obj1, Position obj2)
        {
            return !(obj1 == obj2);
        }
    }
}
