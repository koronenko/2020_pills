﻿using System;
using System.Collections.Generic;
using System.Text;
/// <summary>
/// Напрямок руху для пігулок
/// </summary>
namespace Engine
{
    public enum Move 
    { 
        None,
        Down,
        Left,
        Right,
        Rotate_Right,
        Rotate_Left,
        Fall
    }
}
